
package recuperatorio322p1;


public enum NivelExperiencia {
    DEBUTANTE,
    EXPERIMENTADO,
    VETERANO;
}
