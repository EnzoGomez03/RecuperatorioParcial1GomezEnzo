
package recuperatorio322p1;


public class Arquero extends Futbolista implements Informable{
    
    private int cantidadAtajadas;

    public Arquero(String nombre,String pais,NivelExperiencia experiencia,int numeroCamiseta,int partidosDisputados,int cantidadAtajadas) {
        super(nombre, pais, experiencia,numeroCamiseta, partidosDisputados);
        validarAtajadasRealizadas(cantidadAtajadas);
        this.cantidadAtajadas = cantidadAtajadas;
    }

    /**
     * Valida que las atajadas no sean menor a 0
     * @param atajadasAValidar 
     */
    private void validarAtajadasRealizadas(int atajadasAValidar){
        if (atajadasAValidar < 0) {
            throw new IllegalArgumentException("Las atajadas realizadas no pueden ser menor a 0.");
        }
    }

    public int getCantidadAtajadas() {
        return cantidadAtajadas;
    }
    
    
    @Override
    public String informe() {
        return "Informe del arquero " + getNombre()
            + ": " + cantidadAtajadas
            + " atajadas en "
            + getCantidadPartidos()
            + " partidos.";
    }
    
    @Override
    public String entrenar() {
        return "El futbolista " + getNombre() + " de " + getPais() + " realizo el entrenamiento.";
    }
    
    @Override
    public String toString() {
        return "Arquero [nombre=" + getNombre()
                + ", pais=" + getPais()
                + ", experiencia=" + getNivelDeExperiencia()
                + ", numeroCamiseta=" + getNumeroCamiseta()
                + ", partidosDisputados=" + getCantidadPartidos()
                + ", atajadasRealizadas=" + cantidadAtajadas
                + "]";
}
}
