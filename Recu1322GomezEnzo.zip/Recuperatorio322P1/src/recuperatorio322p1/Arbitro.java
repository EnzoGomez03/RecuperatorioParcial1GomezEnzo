
package recuperatorio322p1;


public class Arbitro extends Participante implements Informable{
    private int cantidadPartidosDir;

    public Arbitro(String nombre,String pais,NivelExperiencia experiencia,int cantidadPartidosDir) {
        super(nombre, pais, experiencia);
        validarPartidosDirigidos(cantidadPartidosDir);
        this.cantidadPartidosDir = cantidadPartidosDir;
    }
    
    /**
     * Valida que la cantidadPartidosDir no sea menor a 0
     * @param partidosAValidar 
     */
    
    private void validarPartidosDirigidos(int partidosAValidar){
        if(partidosAValidar < 0){
            throw new IllegalArgumentException("Los partidos dirigidos no pueden ser menor a 0");
        }
    }
    
    @Override
    public String informe() {
        return "Informe del arbitro "
                + getNombre()
                + ": "
                + cantidadPartidosDir
                + " partidos dirigidos.";
    }

    @Override
    public String toString() {
        return "Arbitro [nombre=" + getNombre()
                + ", pais=" + getPais()
                + ", experiencia=" + getNivelDeExperiencia()
                + ", partidosDirigidos=" + cantidadPartidosDir
                + "]";
    }
    
}
