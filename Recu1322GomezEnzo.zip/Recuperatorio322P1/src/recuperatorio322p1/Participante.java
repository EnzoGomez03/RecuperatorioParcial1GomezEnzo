package recuperatorio322p1;

import java.util.Objects;


public abstract class Participante {
    private String nombre;
    private String pais;
    private NivelExperiencia nivelDeExperiencia;

    public Participante(String nombre, String pais, NivelExperiencia nivelDeExperiencia) {
        validarString(nombre, "El nombre del participante no puede estar vacio.");
        validarString(pais, "El pais del participante no puede estar vacio.");
        validarExperiencia(nivelDeExperiencia);
        this.nombre = nombre;
        this.pais = pais;
        this.nivelDeExperiencia = nivelDeExperiencia;
    }
    
    /**
     * Valida que el nivel de experiencia no sea null
     * @param experienciaAValidar 
     */
    public void validarExperiencia(NivelExperiencia experienciaAValidar){
        if (experienciaAValidar == null) {
            throw new IllegalArgumentException(
                    "La experiencia no puede ser null.");
        }
    }
    
    
     /**
      * Valida que el String pasado por parametro no sea null, ni vacio.
      * @param stringAValidar
      * @param mensaje 
      */
    private void validarString(String stringAValidar,String mensaje) {
        if (stringAValidar == null || stringAValidar.isBlank()) {
            throw new IllegalArgumentException(mensaje);
        }
    }
    
    
    
    public String getNombre() {
        return nombre;
    }

    public String getPais() {
        return pais;
    }

    public NivelExperiencia getNivelDeExperiencia() {
        return nivelDeExperiencia;
    }
    
    
    /**
     * Dos participantes son iguales si tienen el mismo nombre
     * y representan al mismo pais.
     * @param obj
     * @return boolean
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj){
            return true;
        }
        if(obj == null){
            return false;
        }
        if (!(obj instanceof Participante o )){
            return false;
        }
        return Objects.equals(nombre, o.nombre) &&
               Objects.equals(pais, o.pais);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, pais);
    }

    @Override
    public String toString() {
        return "Participante{" +
                "nombre=" + nombre +
                ", pais=" + pais +
                ", experiencia=" + nivelDeExperiencia +
                '}';
    }
}
