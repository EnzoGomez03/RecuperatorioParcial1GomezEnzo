package recuperatorio322p1;


public class JugadorDeCampo extends Futbolista{
    private final int cantidadGoles;

     public JugadorDeCampo(String nombre,String pais,NivelExperiencia experiencia,int numeroCamiseta,int partidosDisputados,int cantidadGoles) {
        super(nombre, pais, experiencia,numeroCamiseta, partidosDisputados);
        validarGolesConvertidos(cantidadGoles);
        this.cantidadGoles = cantidadGoles;
    }
     
     
     public void validarGolesConvertidos(int totalGolesAValidar){
         if (totalGolesAValidar < 0) {
            throw new IllegalArgumentException("Los goles convertidos no pueden ser negativos.");
        }
     }

    public int getCantidadGoles() {
        return cantidadGoles;
    }
     
     
    @Override
    public String entrenar() {
        return "El futbolista " + getNombre() + " de " + getPais() + " realizo el entrenamiento.";
    }
    
    @Override
    public String toString() {
        return "JugadorDeCampo [nombre=" + getNombre()
                + ", pais=" + getPais()
                + ", experiencia=" + getNivelDeExperiencia()
                + ", numeroCamiseta=" + getNumeroCamiseta()
                + ", partidosDisputados=" + getCantidadPartidos()
                + ", golesConvertidos=" + cantidadGoles
                + "]";
    }
    
}
