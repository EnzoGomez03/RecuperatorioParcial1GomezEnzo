package recuperatorio322p1;


public class ParticipanteDuplicadoException extends Exception{
    
    public ParticipanteDuplicadoException(String mensaje) {
        super(mensaje);
    }
}
