package recuperatorio322p1;

import java.util.ArrayList;
import java.util.List;


public class DelegacionMundial {
    private final String nombre;
    private List<Participante> participantes;
    
    public DelegacionMundial(String nombre) {
        validarNombre(nombre);
        this.nombre = nombre;
        this.participantes = new ArrayList<>();
    }
    
    private void validarNombre(String nombreAValidar){
        if (nombreAValidar == null || nombreAValidar.isBlank()) {
            throw new IllegalArgumentException("El nombre de la delegacion no puede estar vacio.");
        }
    }
    
    
    public void agregarParticipante (Participante participante)throws ParticipanteDuplicadoException{
        validarParticipante(participante);
        participantes.add(participante);
    }
    
    /**
     * Valida que el participante no sea null, y que tampoco este repetido
     */
    private void validarParticipante(Participante participanteAValidar)throws ParticipanteDuplicadoException{
         if (participanteAValidar == null) {
            throw new IllegalArgumentException(
                    "El participante enviado no puede ser null.");
        }

        if (participantes.contains(participanteAValidar)) {
            throw new ParticipanteDuplicadoException(
                    "Ya existe un participante llamado '"
                    + participanteAValidar.getNombre()
                    + "' que representa a '"
                    + participanteAValidar.getPais()
                    + "'."
            );
        }
    }
    
    public List<Participante> obtenerParticipantes() {
        return participantes;
    }
    
    public List<Participante> filtrarPorExperiencia(
            NivelExperiencia experiencia) {

        List<Participante> participantesFiltrados = new ArrayList<>();

        for (Participante participante : participantes) {
            if (participante.getNivelDeExperiencia() == experiencia) {
                participantesFiltrados.add(participante);
            }
        }

        return participantesFiltrados;
    }

    public String getNombre() {
        return nombre;
    }
}
