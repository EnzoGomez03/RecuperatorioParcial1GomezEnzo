package recuperatorio322p1;


public abstract class Futbolista extends Participante implements Entrenable{
    
    private int numeroCamiseta;
    private int cantidadPartidos;

    public Futbolista(String nombre, String pais, NivelExperiencia nivelDeExperiencia, int numeroCamiseta, int cantidadPartidos) {
        super(nombre, pais, nivelDeExperiencia);
        validarCamiseta(numeroCamiseta);
        validarPartidos(cantidadPartidos);
        this.numeroCamiseta = numeroCamiseta;
        this.cantidadPartidos = cantidadPartidos;
    }

    /**
     * Valida que el numero de camiseta sea mayor o igual a 0
     * @param numeroAValidar 
     */
    private void validarCamiseta(int numeroAValidar){
        if (numeroAValidar <= 0) {
            throw new IllegalArgumentException("El numero de camiseta debe ser mayor a 0.");
        }
    }
    
    /**
     * Valida que la cantidad de partidos disputados no sea menor a 0
     * @param partidosAValidar 
     */
    private void validarPartidos(int partidosAValidar){
         if (partidosAValidar < 0) {
            throw new IllegalArgumentException("Los partidos disputados no pueden ser menor a 0.");
        }
    }
    
    public int getNumeroCamiseta() {
        return numeroCamiseta;
    }

    public int getCantidadPartidos() {
        return cantidadPartidos;
    }
    
}
