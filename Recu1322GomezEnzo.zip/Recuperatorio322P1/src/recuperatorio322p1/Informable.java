package recuperatorio322p1;

public interface Informable {
    
    String informe();
}
