package recuperatorio322p1;


public interface Entrenable {
    String entrenar();
}
